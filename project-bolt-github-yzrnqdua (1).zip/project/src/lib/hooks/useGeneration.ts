```typescript
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { checkCredits, deductCredits } from '@/lib/api/credits';
import { generateContent } from '@/lib/api/generation';
import { GENERATION_CREDITS, GenerationType } from '@/lib/constants/credits';
import { supabase } from '@/integrations/supabase/client';
import { AuthenticationError, CreditError, GenerationError } from '@/lib/api/errors';
import { logger } from '@/lib/utils/logger';

interface UseGenerationOptions {
  onSuccess?: (data: any) => void;
  onError?: (error: Error) => void;
}

export function useGeneration(type: GenerationType, options: UseGenerationOptions = {}) {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const generate = async (payload: any) => {
    setIsLoading(true);
    logger.info(`Starting ${type} generation`, { payload });

    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new AuthenticationError();
      }

      // Check credits
      const creditCheck = await checkCredits(user.id, GENERATION_CREDITS[type]);
      if (!creditCheck.has_credits) {
        throw new CreditError(
          creditCheck.error_message || 'Insufficient credits',
          user.id,
          GENERATION_CREDITS[type]
        );
      }

      // Generate content
      const result = await generateContent(type, payload);

      // Deduct credits
      await deductCredits(user.id, GENERATION_CREDITS[type]);

      logger.info(`${type} generation completed successfully`);
      options.onSuccess?.(result);
      return result;
    } catch (error) {
      logger.error(`Error in ${type} generation`, { error });

      let message = 'An unexpected error occurred';
      let variant: 'default' | 'destructive' = 'destructive';

      if (error instanceof AuthenticationError) {
        message = 'Please sign in to continue';
      } else if (error instanceof CreditError) {
        message = error.message;
        variant = 'default';
      } else if (error instanceof GenerationError) {
        message = error.message;
      }
      
      toast({
        title: `Generation Failed`,
        description: message,
        variant
      });

      options.onError?.(error as Error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    generate,
    isLoading
  };
}
```