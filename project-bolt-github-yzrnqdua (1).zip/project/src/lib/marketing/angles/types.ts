```typescript
export type MarketingAngleType = 
  | 'PROBLEM_AGITATION'
  | 'UNIQUE_MECHANISM'
  | 'SOCIAL_PROOF'
  | 'SCARCITY'
  | 'FUTURE_PACING'
  | 'COMPETITIVE_EDGE'
  | 'RISK_REVERSAL'
  | 'VALUE_STACKING';

export type AwarenessLevel = 
  | 'UNAWARE'
  | 'PROBLEM_AWARE'
  | 'SOLUTION_AWARE'
  | 'PRODUCT_AWARE'
  | 'MOST_AWARE';

export type SophisticationLevel =
  | 'LOW'
  | 'MEDIUM'
  | 'HIGH';

export interface MarketingAngle {
  type: MarketingAngleType;
  description: string;
  template: string;
  awarenessLevel: AwarenessLevel;
  sophisticationLevel: SophisticationLevel;
}
```