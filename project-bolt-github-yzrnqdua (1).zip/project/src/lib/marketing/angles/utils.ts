```typescript
import { AwarenessLevel, SophisticationLevel, MarketingAngle } from './types';
import { MARKETING_ANGLES } from './templates';
import { AudienceAnalysis } from '@/types/adWizard';

export function determineAwarenessLevel(analysis: AudienceAnalysis): AwarenessLevel {
  const { awarenessLevel, sophisticationLevel } = analysis;
  
  if (awarenessLevel.toLowerCase().includes('high')) return 'MOST_AWARE';
  if (awarenessLevel.toLowerCase().includes('medium')) return 'SOLUTION_AWARE';
  if (awarenessLevel.toLowerCase().includes('low')) return 'PROBLEM_AWARE';
  return 'UNAWARE';
}

export function determineSophisticationLevel(analysis: AudienceAnalysis): SophisticationLevel {
  const { sophisticationLevel } = analysis;
  
  if (sophisticationLevel.toLowerCase().includes('high')) return 'HIGH';
  if (sophisticationLevel.toLowerCase().includes('medium')) return 'MEDIUM';
  return 'LOW';
}

export function getRelevantAngles(analysis: AudienceAnalysis): MarketingAngle[] {
  const awareness = determineAwarenessLevel(analysis);
  const sophistication = determineSophisticationLevel(analysis);

  return Object.values(MARKETING_ANGLES).filter(angle => {
    // Match awareness level exactly or one level above/below
    const awarenessMatch = 
      angle.awarenessLevel === awareness ||
      (awareness === 'MOST_AWARE' && angle.awarenessLevel === 'PRODUCT_AWARE') ||
      (awareness === 'PRODUCT_AWARE' && angle.awarenessLevel === 'SOLUTION_AWARE');

    // Match sophistication level exactly or one level below
    const sophisticationMatch =
      angle.sophisticationLevel === sophistication ||
      (sophistication === 'HIGH' && angle.sophisticationLevel === 'MEDIUM') ||
      (sophistication === 'MEDIUM' && angle.sophisticationLevel === 'LOW');

    return awarenessMatch && sophisticationMatch;
  });
}
```