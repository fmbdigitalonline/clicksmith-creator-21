```typescript
import { MarketingAngle } from './types';

export const MARKETING_ANGLES: Record<string, MarketingAngle> = {
  PROBLEM_AGITATION: {
    type: 'PROBLEM_AGITATION',
    description: 'Amplify the pain points to create emotional resonance',
    template: 'Highlight how [pain_point] is costing [target] their [desired_outcome]',
    awarenessLevel: 'PROBLEM_AWARE',
    sophisticationLevel: 'LOW'
  },
  UNIQUE_MECHANISM: {
    type: 'UNIQUE_MECHANISM',
    description: 'Focus on the unique way your solution works',
    template: 'Reveal the [unique_aspect] that makes [solution] different from [alternatives]',
    awarenessLevel: 'SOLUTION_AWARE',
    sophisticationLevel: 'MEDIUM'
  },
  SOCIAL_PROOF: {
    type: 'SOCIAL_PROOF',
    description: 'Leverage success stories and testimonials',
    template: 'Show how [customer_type] achieved [specific_result] using [solution]',
    awarenessLevel: 'PRODUCT_AWARE',
    sophisticationLevel: 'MEDIUM'
  },
  SCARCITY: {
    type: 'SCARCITY',
    description: 'Create urgency through limited availability',
    template: 'Only [number] spots available for [exclusive_benefit]',
    awarenessLevel: 'MOST_AWARE',
    sophisticationLevel: 'HIGH'
  },
  FUTURE_PACING: {
    type: 'FUTURE_PACING',
    description: 'Paint a picture of the desired future outcome',
    template: 'Imagine [timeframe] from now, when you [desired_outcome]',
    awarenessLevel: 'PROBLEM_AWARE',
    sophisticationLevel: 'LOW'
  },
  COMPETITIVE_EDGE: {
    type: 'COMPETITIVE_EDGE',
    description: 'Highlight key differentiators from competitors',
    template: 'Unlike [competitor_approach], our [unique_feature] delivers [benefit]',
    awarenessLevel: 'SOLUTION_AWARE',
    sophisticationLevel: 'HIGH'
  },
  RISK_REVERSAL: {
    type: 'RISK_REVERSAL',
    description: 'Remove barriers to action by addressing fears',
    template: 'Try [solution] risk-free - [guarantee] or [compensation]',
    awarenessLevel: 'PRODUCT_AWARE',
    sophisticationLevel: 'HIGH'
  },
  VALUE_STACKING: {
    type: 'VALUE_STACKING',
    description: 'Stack multiple benefits to increase perceived value',
    template: 'Get [benefit_1], [benefit_2], and [benefit_3] in one [solution]',
    awarenessLevel: 'MOST_AWARE',
    sophisticationLevel: 'MEDIUM'
  }
};
```