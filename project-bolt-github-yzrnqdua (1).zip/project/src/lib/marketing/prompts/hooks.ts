```typescript
import { BusinessIdea, TargetAudience, AudienceAnalysis } from "@/types/adWizard";
import { getRelevantAngles } from "../angles/utils";

export function generateHooksPrompt(
  businessIdea: BusinessIdea,
  targetAudience: TargetAudience,
  audienceAnalysis: AudienceAnalysis
): string {
  const relevantAngles = getRelevantAngles(audienceAnalysis);
  const angleTypes = relevantAngles.map(angle => angle.type).join(', ');

  return `Create marketing hooks for this business and audience:

Business Context:
${businessIdea.description}
Value Proposition: ${businessIdea.valueProposition}

Target Audience:
${JSON.stringify(targetAudience, null, 2)}

Audience Analysis:
${JSON.stringify(audienceAnalysis, null, 2)}

Relevant Marketing Angles: ${angleTypes}

Create hooks that:
1. Match the audience's awareness level (${audienceAnalysis.awarenessLevel})
2. Address specific pain points directly
3. Consider market sophistication (${audienceAnalysis.sophisticationLevel})
4. Align with the value proposition
5. Counter potential objections

Return a JSON array with exactly 5 items in this format:
[{
  "text": "string (the actual hook text)",
  "description": "string (marketing angle and strategy)",
  "marketingAngle": {
    "type": "string (one of the relevant angles)",
    "focus": "string (specific pain point or desire)",
    "strategy": "string (how this connects with the audience)"
  }
}]`;
}
```