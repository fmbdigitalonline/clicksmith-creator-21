```typescript
import { BusinessIdea, TargetAudience } from "@/types/adWizard";

export function generateAnalysisPrompt(businessIdea: BusinessIdea, targetAudience: TargetAudience): string {
  return `Analyze this target audience for a business:

Business Context:
${businessIdea.description}
Value Proposition: ${businessIdea.valueProposition}

Target Audience:
Name: ${targetAudience.name}
Description: ${targetAudience.description}
Demographics: ${targetAudience.demographics}
Pain Points: ${targetAudience.painPoints.join(', ')}
ICP: ${targetAudience.icp}
Core Message: ${targetAudience.coreMessage}

Return a JSON object with:
{
  "expandedDefinition": "string describing potential group struggling with a problem",
  "marketDesire": "string describing deep market desire",
  "awarenessLevel": "string describing familiarity with problem/solution",
  "sophisticationLevel": "string describing familiarity with competing solutions",
  "deepPainPoints": ["3 main problems as array of strings"],
  "potentialObjections": ["3 main objections as array of strings"]
}`;
}
```