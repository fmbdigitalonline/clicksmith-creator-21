```typescript
import { BusinessIdea } from "@/types/adWizard";

export function generateAudiencePrompt(businessIdea: BusinessIdea): string {
  return `Analyze this business to identify 3 distinct target audiences:

Business Context:
${businessIdea.description}
Value Proposition: ${businessIdea.valueProposition}

For each audience, provide:
1. Name and description
2. Demographic information
3. Key pain points (3 specific challenges)
4. Ideal Customer Profile (ICP)
5. Core messaging strategy
6. Market positioning
7. Marketing approach
8. Recommended channels

Return a JSON array with 3 audience objects containing:
{
  "name": "string",
  "description": "string",
  "painPoints": ["string", "string", "string"],
  "demographics": "string",
  "icp": "string",
  "coreMessage": "string",
  "positioning": "string",
  "marketingAngle": "string",
  "messagingApproach": "string",
  "marketingChannels": ["string"]
}`;
}
```