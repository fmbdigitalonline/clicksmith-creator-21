```typescript
export * from './types';
export * from './facebook';
export * from './google';

import { FACEBOOK_AD_FORMATS } from './facebook';
import { GOOGLE_AD_FORMATS } from './google';
import type { AdFormatGroup, AdFormat } from './types';

export function getAllAdFormats(): AdFormatGroup[] {
  return [...FACEBOOK_AD_FORMATS, ...GOOGLE_AD_FORMATS];
}

export function getAdFormatsByPlatform(platform: 'facebook' | 'google'): AdFormatGroup[] {
  return platform === 'facebook' ? FACEBOOK_AD_FORMATS : GOOGLE_AD_FORMATS;
}

export function getAdFormatsByType(type: 'image' | 'video' | 'text'): AdFormat[] {
  return getAllAdFormats()
    .flatMap(group => group.formats)
    .filter(format => format.type === type);
}

export function validateAdFormat(format: AdFormat, file: File): string | null {
  if (!format.requirements) return null;

  const { maxFileSize, allowedFormats, maxLength, minLength } = format.requirements;

  if (maxFileSize) {
    const sizeInMB = file.size / (1024 * 1024);
    const maxSizeInMB = parseInt(maxFileSize);
    if (sizeInMB > maxSizeInMB) {
      return `File size exceeds maximum of ${maxFileSize}`;
    }
  }

  if (allowedFormats) {
    const fileExt = `.${file.name.split('.').pop()?.toLowerCase()}`;
    if (!allowedFormats.includes(fileExt)) {
      return `File type not allowed. Supported formats: ${allowedFormats.join(', ')}`;
    }
  }

  return null;
}
```