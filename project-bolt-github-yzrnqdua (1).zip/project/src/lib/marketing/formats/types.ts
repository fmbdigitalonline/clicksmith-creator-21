```typescript
export interface AdDimensions {
  width: number;
  height: number;
  minWidth?: number;
  minHeight?: number;
}

export interface AdFormat {
  format: string;
  dimensions: AdDimensions;
  aspectRatio: string;
  description: string;
  platform: 'facebook' | 'google';
  type: 'image' | 'video' | 'text';
  requirements?: {
    maxFileSize?: string;
    allowedFormats?: string[];
    maxLength?: string;
    minLength?: string;
  };
}

export interface AdFormatGroup {
  name: string;
  description: string;
  formats: AdFormat[];
}
```