```typescript
import { AdFormatGroup } from './types';

export const GOOGLE_AD_FORMATS: AdFormatGroup[] = [
  {
    name: 'Display Ads',
    description: 'Static image ads for the Google Display Network',
    formats: [
      {
        format: 'Horizontal Banner',
        dimensions: {
          width: 1200,
          height: 628,
          minWidth: 600,
          minHeight: 314
        },
        aspectRatio: '1.91:1',
        description: 'Standard horizontal banner for websites and apps',
        platform: 'google',
        type: 'image',
        requirements: {
          maxFileSize: '5MB',
          allowedFormats: ['.jpg', '.png']
        }
      },
      {
        format: 'Square Display',
        dimensions: {
          width: 1200,
          height: 1200,
          minWidth: 300,
          minHeight: 300
        },
        aspectRatio: '1:1',
        description: 'Versatile square format for all placements',
        platform: 'google',
        type: 'image',
        requirements: {
          maxFileSize: '5MB',
          allowedFormats: ['.jpg', '.png']
        }
      },
      {
        format: 'Portrait Display',
        dimensions: {
          width: 1200,
          height: 1500,
          minWidth: 480,
          minHeight: 600
        },
        aspectRatio: '4:5',
        description: 'Vertical format optimized for mobile',
        platform: 'google',
        type: 'image',
        requirements: {
          maxFileSize: '5MB',
          allowedFormats: ['.jpg', '.png']
        }
      }
    ]
  },
  {
    name: 'Video Ads',
    description: 'Video advertisements for YouTube and Display Network',
    formats: [
      {
        format: 'YouTube Landscape',
        dimensions: {
          width: 1920,
          height: 1080
        },
        aspectRatio: '16:9',
        description: 'Standard YouTube video format',
        platform: 'google',
        type: 'video',
        requirements: {
          maxFileSize: '256GB',
          allowedFormats: ['.mp4', '.mov', '.avi'],
          maxLength: '60 seconds',
          minLength: '10 seconds'
        }
      },
      {
        format: 'YouTube Square',
        dimensions: {
          width: 1080,
          height: 1080
        },
        aspectRatio: '1:1',
        description: 'Square video for in-feed ads',
        platform: 'google',
        type: 'video',
        requirements: {
          maxFileSize: '256GB',
          allowedFormats: ['.mp4', '.mov', '.avi'],
          maxLength: '60 seconds',
          minLength: '15 seconds'
        }
      },
      {
        format: 'YouTube Shorts',
        dimensions: {
          width: 1080,
          height: 1920
        },
        aspectRatio: '9:16',
        description: 'Vertical video for YouTube Shorts',
        platform: 'google',
        type: 'video',
        requirements: {
          maxFileSize: '256GB',
          allowedFormats: ['.mp4', '.mov', '.avi'],
          maxLength: '60 seconds',
          minLength: '6 seconds'
        }
      }
    ]
  },
  {
    name: 'Text Ads',
    description: 'Text-based advertisements for Search Network',
    formats: [
      {
        format: 'Expanded Text Ad',
        dimensions: {
          width: 0,
          height: 0
        },
        aspectRatio: 'N/A',
        description: 'Text-only search ad with multiple headlines and descriptions',
        platform: 'google',
        type: 'text',
        requirements: {
          maxLength: '30-40 chars per headline, 90 chars per description'
        }
      },
      {
        format: 'Responsive Search Ad',
        dimensions: {
          width: 0,
          height: 0
        },
        aspectRatio: 'N/A',
        description: 'Dynamic text ad that adapts to available space',
        platform: 'google',
        type: 'text',
        requirements: {
          maxLength: 'Up to 15 headlines, 4 descriptions'
        }
      }
    ]
  }
];
```