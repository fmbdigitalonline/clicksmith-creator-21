```typescript
import { AdFormatGroup } from './types';

export const FACEBOOK_AD_FORMATS: AdFormatGroup[] = [
  {
    name: 'Feed Ads',
    description: 'Advertisements that appear in the Facebook news feed',
    formats: [
      {
        format: 'Single Image Feed',
        dimensions: {
          width: 1080,
          height: 1080
        },
        aspectRatio: '1:1',
        description: 'Square image for news feed posts',
        platform: 'facebook',
        type: 'image',
        requirements: {
          maxFileSize: '30MB',
          allowedFormats: ['.jpg', '.png']
        }
      },
      {
        format: 'Landscape Feed',
        dimensions: {
          width: 1200,
          height: 628
        },
        aspectRatio: '1.91:1',
        description: 'Horizontal image optimized for desktop',
        platform: 'facebook',
        type: 'image',
        requirements: {
          maxFileSize: '30MB',
          allowedFormats: ['.jpg', '.png']
        }
      },
      {
        format: 'Portrait Feed',
        dimensions: {
          width: 1080,
          height: 1350
        },
        aspectRatio: '4:5',
        description: 'Vertical image optimized for mobile',
        platform: 'facebook',
        type: 'image',
        requirements: {
          maxFileSize: '30MB',
          allowedFormats: ['.jpg', '.png']
        }
      }
    ]
  },
  {
    name: 'Story Ads',
    description: 'Full-screen vertical advertisements for Stories',
    formats: [
      {
        format: 'Story Image',
        dimensions: {
          width: 1080,
          height: 1920
        },
        aspectRatio: '9:16',
        description: 'Full-screen vertical image for Stories',
        platform: 'facebook',
        type: 'image',
        requirements: {
          maxFileSize: '30MB',
          allowedFormats: ['.jpg', '.png']
        }
      },
      {
        format: 'Story Video',
        dimensions: {
          width: 1080,
          height: 1920
        },
        aspectRatio: '9:16',
        description: 'Full-screen vertical video for Stories',
        platform: 'facebook',
        type: 'video',
        requirements: {
          maxFileSize: '4GB',
          allowedFormats: ['.mp4', '.mov'],
          maxLength: '120 seconds'
        }
      }
    ]
  }
];
```