```typescript
type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  details?: any;
}

class Logger {
  private logs: LogEntry[] = [];

  private log(level: LogLevel, message: string, details?: any) {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      details
    };

    this.logs.push(entry);
    
    // Always console log in development
    if (process.env.NODE_ENV === 'development') {
      console[level](message, details);
    }

    return entry;
  }

  debug(message: string, details?: any) {
    return this.log('debug', message, details);
  }

  info(message: string, details?: any) {
    return this.log('info', message, details);
  }

  warn(message: string, details?: any) {
    return this.log('warn', message, details);
  }

  error(message: string, details?: any) {
    return this.log('error', message, details);
  }

  getRecentLogs(count: number = 10): LogEntry[] {
    return this.logs.slice(-count);
  }

  clearLogs() {
    this.logs = [];
  }
}

export const logger = new Logger();
```