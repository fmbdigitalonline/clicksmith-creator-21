```typescript
export class GenerationError extends Error {
  constructor(
    message: string,
    public type: string,
    public details?: any
  ) {
    super(message);
    this.name = 'GenerationError';
  }
}

export class CreditError extends Error {
  constructor(
    message: string,
    public userId: string,
    public requiredCredits: number
  ) {
    super(message);
    this.name = 'CreditError';
  }
}

export class AuthenticationError extends Error {
  constructor(message: string = 'User not authenticated') {
    super(message);
    this.name = 'AuthenticationError';
  }
}
```