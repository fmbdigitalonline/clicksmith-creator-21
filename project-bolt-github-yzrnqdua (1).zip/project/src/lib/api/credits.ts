```typescript
import { supabase } from "@/integrations/supabase/client";
import { CreditError } from "./errors";
import { logger } from "@/lib/utils/logger";

export async function checkCredits(userId: string, requiredCredits: number) {
  logger.info('Checking credits', { userId, requiredCredits });

  try {
    const { data, error } = await supabase.rpc(
      'check_user_credits',
      { 
        p_user_id: userId,
        required_credits: requiredCredits 
      }
    );

    if (error) {
      logger.error('Credit check error', { error, userId, requiredCredits });
      throw new CreditError(
        `Failed to check credits: ${error.message}`,
        userId,
        requiredCredits
      );
    }

    logger.info('Credit check result', { result: data[0] });
    return data[0];
  } catch (error) {
    if (error instanceof CreditError) {
      throw error;
    }

    logger.error('Unexpected error checking credits', { error, userId, requiredCredits });
    throw new CreditError(
      'Unexpected error checking credits',
      userId,
      requiredCredits
    );
  }
}

export async function deductCredits(userId: string, credits: number) {
  logger.info('Deducting credits', { userId, credits });

  try {
    const { data, error } = await supabase.rpc(
      'deduct_user_credits',
      { 
        input_user_id: userId,
        credits_to_deduct: credits 
      }
    );

    if (error) {
      logger.error('Credit deduction error', { error, userId, credits });
      throw new CreditError(
        `Failed to deduct credits: ${error.message}`,
        userId,
        credits
      );
    }

    logger.info('Credits deducted successfully', { result: data[0] });
    return data[0];
  } catch (error) {
    if (error instanceof CreditError) {
      throw error;
    }

    logger.error('Unexpected error deducting credits', { error, userId, credits });
    throw new CreditError(
      'Unexpected error deducting credits',
      userId,
      credits
    );
  }
}
```