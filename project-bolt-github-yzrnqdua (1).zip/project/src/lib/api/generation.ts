```typescript
import { supabase } from "@/integrations/supabase/client";
import { GenerationType } from "@/lib/constants/credits";
import { GenerationError } from "./errors";
import { logger } from "@/lib/utils/logger";

export async function generateContent(type: GenerationType, payload: any) {
  logger.info(`Starting ${type} generation`, { payload });

  try {
    const { data, error } = await supabase.functions.invoke('generate-ad-content', {
      body: { 
        type,
        ...payload
      }
    });

    if (error) {
      logger.error(`Generation error for ${type}`, { error, payload });
      throw new GenerationError(
        `Failed to generate ${type}: ${error.message}`,
        type,
        { error, payload }
      );
    }

    logger.info(`Successfully generated ${type}`, { data });
    return data;
  } catch (error) {
    if (error instanceof GenerationError) {
      throw error;
    }

    logger.error(`Unexpected error in ${type} generation`, { error, payload });
    throw new GenerationError(
      `Unexpected error in ${type} generation`,
      type,
      { originalError: error, payload }
    );
  }
}
```